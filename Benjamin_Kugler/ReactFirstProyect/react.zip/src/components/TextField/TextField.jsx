import React from 'react';

const TextField = () =>(<input type="text"/>);

export default TextField;