import React from 'react';
import ReactDOM from 'react-dom';
import TextField from './components/TextField/TextField.jsx';

ReactDOM.render(
    <div> Hola Mundo <TextField /> </div>,
    document.getElementById("main")
);